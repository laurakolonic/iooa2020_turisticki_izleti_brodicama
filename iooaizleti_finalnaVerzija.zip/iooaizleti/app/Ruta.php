<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ruta extends Model
{
    protected $fillable=['id', 'nazivRuta', 'opisRuta', 'image'];
}
