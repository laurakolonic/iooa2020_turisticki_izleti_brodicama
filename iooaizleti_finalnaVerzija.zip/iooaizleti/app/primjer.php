<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class primjer extends Model
{
    //
}
