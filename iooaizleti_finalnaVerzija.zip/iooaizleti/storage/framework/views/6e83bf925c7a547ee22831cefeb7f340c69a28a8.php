
<?php $__env->startSection('content'); ?>
<div class="col-md-16" style="width: 730px;">
<div class="card card-defatult">
    <div class="card-header">
        <?php echo e(isset($putovanje) ? 'Izmijeni putovanje' : 'Kreiraj putovanje'); ?>

    </div>
    <div class="card-body">
        <form action="<?php echo e(isset($putovanje) ? route('putovanje.update', $putovanje->id) : route('putovanje.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($putovanje)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="form-group">
                <label for="datum">Datum</label>
                <input type="date" id="datum" class="form-control" name="datum" value="<?php echo e(isset($putovanje) ? $putovanje->datum : ''); ?>">
            </div>
            <div class="form-group">
                <label for="vrijeme">Vrijeme</label>
                <input type="time" id="vrijeme" class="form-control" name="vrijeme" value="<?php echo e(isset($putovanje) ? $putovanje->vrijeme : ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="brod">Brod</label>
                <select name="brod" id="brod" class="form-control">
                    <?php $__currentLoopData = $brodovi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brod->id); ?>"> <?php echo e($brod->nazivBrod); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="ruta">Ruta</label>
                <select name="ruta" id="ruta" class="form-control">
                    <?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ruta->id); ?>"> <?php echo e($ruta->nazivRuta); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="cijena">Cijena</label>
                <input type="number" id="cijena" class="form-control" name="cijena" value="<?php echo e(isset($putovanje) ? $putovanje->cijena : ''); ?>">
            </div>

            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <button class="btn btn-success">
                    <?php echo e(isset($putovanje) ? 'Izmijeni putovanje' : 'Dodaj putovanje'); ?>

                </button>
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gitiooa\iooa2020_turisticki_izleti_brodicama\iooaizleti\resources\views/cms/putovanje/create.blade.php ENDPATH**/ ?>