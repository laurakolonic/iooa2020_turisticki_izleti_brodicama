<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Izleti</title>
    <!-- Scripts -->
    <style>
        .btn-info{
            color: #fff;
        }
      
    </style>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>


<?php $__env->startSection('content'); ?>


<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->


<!-- Google font -->
<link href="https://fonts.googleapis.com/css?family=Alegreya:700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400" rel="stylesheet">

<!-- Bootstrap -->
<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

<!-- Custom stlylesheet -->
<link type="text/css" rel="stylesheet" href="css/style.css" />
<style>

a:link, a:visited {
background-color: background-color: #495057;
color: white;
padding: 14px 25px;
text-align: center;
text-decoration: none;
display: inline-block;
}
</style>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>



    
    <div class="content">
      
    <?php if(Route::has('login')): ?>
        <div class="top-right links" style="margin-top: 10px; margin-left:5px;">
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->admin == 1): ?>
                <a style="color:white; background-color:silver;" href="<?php echo e(url('/cms/index')); ?>">Admin verzija</a>
                <a style="font-weight:lighter;color:white; background-color:silver; font-size:1vw;" href="<?php echo e(url('/logout')); ?>">Odjavi se</a>
                <?php else: ?>
                <a style="font-weight:lighter;color:white; background-color:silver;font-size:1vw;" href="<?php echo e(url('/logout')); ?>">Odjavi se</a>
                <?php endif; ?>
            <?php else: ?>
                <a style="font-weight:lighter;color:white; background-color:silver;font-size:1vw;"href="<?php echo e(route('login')); ?>">Prijavi se</a>

                <?php if(Route::has('register')): ?>
                    <a style="font-weight:lighter;color:white; background-color:silver; font-size:1vw;"href="<?php echo e(route('register')); ?>">Registraj se</a>
                <?php endif; ?>
            <?php endif; ?>
            
        </div>
    <?php endif; ?>
      
    </div>
</div>
<form action="<?php echo e(route('pregledputovanja.pregled')); ?>" style="margin-left:600px;">

   <div class="card card-default" style="opacity: 0.8; width:300px; ">
    <div class="card-header" style="width:300px;">DATUM</div>
   <div class="form-group">
   
    <input type="date" min="2020-06-01" max="2021-10-20" id="datum" class="form-control" name="datum" value="Unesi datum" style="width: 300px;">
    <button class="btn btn-success" style="margin-left:100px; width: 100px; background-color:silver; border-color: silver; margin-top:5px;"> Traži </button></div>
</div> </div> 
    


</form>






<div class="d-flex justify-content-end mb-2" style="width: 730px;">
</div>
<div class="card card-default" style="opacity: 0.8">        
   

<div class="card-header">PUTOVANJA</div>
<div class="card-body" >
    <table class="table">
        <thead>
            <th>Datum</th>
            <th>Vrijeme</th>
            <th>Brod</th>
            <th>Brod slika</th>
            <th>Ruta</th>
            <th>Ruta slika</th>
            <th>Cijena</th>
            <th></th>
        </thead>

        <tbody>
            <?php $__currentLoopData = $putovanja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $putovanje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($putovanje->datum); ?>

                    </td>
                    <td>
                        <?php echo e($putovanje->vrijeme); ?>

                    </td>
                    <td>
                        <?php echo e($putovanje->brod->nazivBrod); ?>

                    </td>
                   
                        <th>
                            <img src="/app/public/<?php echo e(($putovanje->brod->image)); ?>" width=100px height=60px alt="">
                        </th>

                    
                    <th>
                        <?php echo e($putovanje->ruta->nazivRuta); ?>

                    </th>
                    <th>
                        <img src="/app/public/<?php echo e(($putovanje->ruta->image)); ?>" width=100px height=60px alt="">
                    </th>
                    <th>
                        <?php echo e($putovanje->cijena); ?> EUR
                    </th>
                    <td>
                        <a href="<?php echo e(route('pregledputovanja.rezerviraj', $putovanje->id)); ?>" class="btn btn-secondary btn-sm" style="background-color: #495057;">Odaberi</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

    <script src="//code.jquery.com/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
   

</body>
</html>


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/welcome.blade.php ENDPATH**/ ?>