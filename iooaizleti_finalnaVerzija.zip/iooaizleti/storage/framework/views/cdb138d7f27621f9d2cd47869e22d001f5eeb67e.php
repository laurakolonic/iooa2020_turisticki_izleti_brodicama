
<?php $__env->startSection('content'); ?>
<div class="col-md-16" style="width: 730px;">
<div class="card card-defatult">
    <div class="card-header">
        <?php echo e(isset($zaposlenik) ? 'Izmijeni zaposlenika' : 'Kreiraj zaposlenika'); ?>

    </div>
    <div class="card-body">
        <form action="<?php echo e(isset($zaposlenik) ? route('zaposlenik.update', $zaposlenik->id) : route('zaposlenik.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($zaposlenik)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="form-group">
                <label for="oibZaposlenik">OIB</label>
                <input type="number" id="oibZaposlenik" class="form-control" name="oibZaposlenik" value="<?php echo e(isset($zaposlenik) ? $zaposlenik->oibZaposlenik : ''); ?>">
            </div>
            <div class="form-group">
                <label for="imeZaposlenik">Ime</label>
                <input type="text" id="imeZaposlenik" class="form-control" name="imeZaposlenik" value="<?php echo e(isset($zaposlenik) ? $zaposlenik->imeZaposlenik : ''); ?>">
            </div>
            <div class="form-group">
                <label for="PrezimeZaposlenik">Prezime</label>
                <input type="text" id="PrezimeZaposlenik" class="form-control" name="PrezimeZaposlenik" value="<?php echo e(isset($zaposlenik) ? $zaposlenik->PrezimeZaposlenik : ''); ?>">
            </div>
            <div class="form-group">
                <label for="datumRodenja">Datum rodenja</label>
                <input type="date" id="datumRodenja" class="form-control" name="datumRodenja" value="<?php echo e(isset($zaposlenik) ? $zaposlenik->datumRodenja : ''); ?>">
            </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <button class="btn btn-success">
                    <?php echo e(isset($zaposlenik) ? 'Izmijeni zaposlenika' : 'Dodaj zaposlenika'); ?>

                </button>
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/cms/zaposlenik/create.blade.php ENDPATH**/ ?>