
<?php $__env->startSection('content'); ?>
<div class="col-md-16" style="width: 730px;" >
<div class="card card-defatult">

    <div class="card-header">
        <?php echo e(isset($brod) ? 'Izmijeni brod' : 'Kreiraj brod'); ?>

    </div>
    
    <div class="card-body">
    
        <form action="<?php echo e(isset($brod) ? route('brod.update', $brod->id) : route('brod.store')); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>

            <?php if(isset($brod)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="form-group">
                <label for="nazivBrod">Naziv</label>
                <input type="text" id="nazivBrod" class="form-control" name="nazivBrod" value="<?php echo e(isset($brod) ? $brod->nazivBrod : ''); ?>">
            </div>

            <div class="form-group">
                <label for="opisBrod">Opis</label>
                <input type="text" id="opisBrod" class="form-control" name="opisBrod" value="<?php echo e(isset($brod) ? $brod->opisBrod : ''); ?>">
            </div>

            
            <?php if(isset($brod)): ?>
            <div class="form-group">
                <img src="/app/public/<?php echo e(($brod->image)); ?>" alt="" style="width:150px">
            </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" class="form-control" name="image" id="image">
            </div>
            
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="form-group">
                <button class="btn btn-success">
                    <?php echo e(isset($brod) ? 'Izmijeni brod' : 'Dodaj brod'); ?>                </button>
            </div>

        </form>
    
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gitiooa\iooa2020_turisticki_izleti_brodicama\iooaizleti\resources\views/cms/brod/create.blade.php ENDPATH**/ ?>