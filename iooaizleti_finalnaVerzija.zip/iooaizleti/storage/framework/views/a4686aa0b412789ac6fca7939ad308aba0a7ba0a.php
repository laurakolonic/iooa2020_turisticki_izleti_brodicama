

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-2" style="width: 730px;">
    <a href="<?php echo e(route('kategorija.create')); ?>" class="btn btn-secondary">Dodaj novu kategoriju</a>
    </div>
      <div class="card card-default">
        <div class="card-header">KATEGORIJE</div>
        <?php if($kategorije->count()>0): ?>
        <div class="card-body">
            <table class="table">
                <thead>
                    <th>Naziv kategorije</th>
                    <th>Godina rođenja</th>
                    <th>Tekuća godina</th>
                    <th>Cijena</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($kategorija->nazivKategorija); ?>

                            </td>
                            <td>
                                <?php echo e($kategorija->tekucaGodina); ?>

                            </td>
                            <td>
                                <?php echo e($kategorija->godinaRodenja); ?>

                            </td>
                            <th>
                                <?php echo e($kategorija->cijena); ?>

                            </th>
                            <td>
                                <a href="<?php echo e(route('kategorija.edit', $kategorija->id)); ?>" class="btn btn-secondary btn-sm">Izmijeni</a>
                                <button class="btn btn-secondary btn-sm" onclick="handleDelete(<?php echo e($kategorija->id); ?>)">Izbriši</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form action="" method="POST" id="deleteKategorijaForm">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="deleteModalLabel">Izbriši kategoriju</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <p class="text-center text-bold">Želite li stvarno izbrisati podatak ?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Odustani.</button>
            <button type="submit" class="btn btn-danger">Potvrdi.</button>
          </div>
        </div>
        </form>
      </div>
    </div>
        </div>
    </div>
    <?php else: ?>
    <div class="card-header" mt-5>
        <h4 class="text-center">Nema podataka.</h4>

        </div>
    <?php endif; ?>
    
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
        <script>
            function handleDelete(id){
                var form=document.getElementById('deleteKategorijaForm')
                form.action='/cms/kategorija/'+id
                console.log('deleting', form)
                $('#deleteModal').modal('show')
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/cms/kategorija/index.blade.php ENDPATH**/ ?>