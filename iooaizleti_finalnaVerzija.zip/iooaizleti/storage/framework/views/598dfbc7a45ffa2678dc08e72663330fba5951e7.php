<?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
<?php if(session()->has('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php endif; ?><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/layouts/alerts.blade.php ENDPATH**/ ?>