
<?php $__env->startSection('content'); ?>
<div id="pregledGosti" style="    width: 100%; ">
<form action="<?php echo e(route('gostPutovanje.pregled')); ?>" style="margin-left:85px; ">
<div class="card-header" style="width:300px;">DATUM</div>
  <div class="form-group">
  
   <input type="date" min="2020-06-01" max="2021-10-20" id="datum" class="form-control" name="datum" value="Unesi datum" style="width: 300px;">
   <button class="btn btn-success" style=" width: 100px; background-color:gray; border-color: silver; margin-top:5px; margin-left:100px;"> Traži </button></div>
</div> </div> 
  <div class="card card-default" style="opacity: 0.8; width:600px; margin-left:60px;">
   

<div class="d-flex justify-content-end mb-2">
</div>
  <div class="card card-defatult">
    <div class="card-header" style=" background-color:silver; ">GOST</div>
    <?php if($gosti->count()>0): ?>
    <div class="card-body">
        <table class="table">
            <thead>
              
               <th>GOST</th>
               <th>PUTOVANJE - DATUM</th>
               <th>PUTOVANJE - VRIJEME</th>
               <th>CIJENA</th> 
                
                
            </thead>
            <tbody>
                <?php $__currentLoopData = $gosti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <?php echo e($gost->gost->imeUser); ?> <?php echo e($gost->gost->prezimeUser); ?>

                  </td>
                  <th>
                    <?php echo e($gost->putovanje->datum); ?>

                  </th>
                  <th>
                    <?php echo e($gost->putovanje->vrijeme); ?>

                  </th>
                  <th>
                    <?php echo e($gost->cijenaGosta); ?>  KN              
                   </th>
                  <td>
                  </td>
              </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    
  </div>
</div>
    </div>
</div>
<?php else: ?>
<div class="card-header" mt-5>
 
          </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gitiooa\iooa2020_turisticki_izleti_brodicama\iooaizleti\resources\views/cms/gostPutovanje/index.blade.php ENDPATH**/ ?>