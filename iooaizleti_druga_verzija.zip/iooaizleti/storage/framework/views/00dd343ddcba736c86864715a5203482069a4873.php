
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-2">
  <a href="<?php echo e(route('brod.create')); ?>" class="btn btn-secondary">Dodaj novi brod</a>
</div>
  <div class="card card-defatult">
    <div class="card-header">BROD</div>
    <?php if($brodice->count()>0): ?>
    <div class="card-body">
        <table class="table">
            <thead>
                <th>NAZIV</th>
                <th>OPIS</th>
                
                <th>SLIKA</th>
                <th></th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $brodice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($brod->nazivBrod); ?>

                        </td>
                        <th>
                            <?php echo e($brod->opisBrod); ?>

                        </th>
                      
                        <th>
                            <img src="/app/public/<?php echo e(($brod->image)); ?>" width=100px height=60px alt="">
                        </th>
                        <td>
                          <a href="<?php echo e(route('brod.edit', $brod->id)); ?>" class="btn btn-secondary btn-sm">Izmijeni</a>
                                <button class="btn btn-secondary btn-sm" onclick="handleDelete(<?php echo e($brod->id); ?>)">Izbriši</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form action="" method="POST" id="deleteBrodForm">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Izbriši brod</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <p class="text-center text-bold">Želite li stvarno izbrisati podatak ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Odustani.</button>
        <button type="submit" class="btn btn-danger">Potvrdi.</button>
      </div>
    </div>
    </form>
  </div>
</div>
    </div>
</div>
<?php else: ?>
<div class="card-header" mt-5>
  <h4 class="text-center">Nema podataka.</h4>
          </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleDelete(id){
                var form=document.getElementById('deleteBrodForm')
                form.action='/cms/brod/'+id
                console.log('deleting', form)
                $('#deleteModal').modal('show')
            
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/cms/brod/index.blade.php ENDPATH**/ ?>