<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gostPutovanje extends Model
{
    //
}
