

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-2" style="width: 730px;" >
    <a href="<?php echo e(route('ruta.create')); ?>" class="btn btn-secondary">Dodaj novu rutu</a>
    </div>
      <div class="card card-default">
        <div class="card-header">RUTE</div>
        <?php if($rute->count()>0): ?>
        <div class="card-body">
            <table class="table">
                <thead>
                    <th>NAZIV</th>
                    <th>OPIS</th>
                   
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($ruta->nazivRuta); ?>

                            </td>
                            <td>
                                <?php echo e($ruta->opisRuta); ?>

                            </td>
                            
                            <td>
                                <a href="<?php echo e(route('ruta.edit', $ruta->id)); ?>" class="btn btn-secondary btn-sm">Izmijeni</a>
                                <button class="btn btn-secondary btn-sm" onclick="handleDelete(<?php echo e($ruta->id); ?>)">Izbriši</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form action="" method="POST" id="deleteRutaForm">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="deleteModalLabel">Izbriši rutu</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <p class="text-center text-bold">Želite li stvarno izbrisati podatak ?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Odustani.</button>
            <button type="submit" class="btn btn-danger">Potvrdi.</button>
          </div>
        </div>
        </form>
      </div>
    </div>
        </div>
    </div>
    <?php else: ?>
    <div class="card-header" mt-5>
        <h4 class="text-center">Nema podataka.</h4>
       
        </div>
    <?php endif; ?>
    
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
        <script>
            function handleDelete(id){
                var form=document.getElementById('deleteRutaForm')
                form.action='/cms/ruta/'+id
                console.log('deleting', form)
                $('#deleteModal').modal('show')
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/cms/ruta/index.blade.php ENDPATH**/ ?>