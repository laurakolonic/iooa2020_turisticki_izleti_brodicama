<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Izleti</title>
    <!-- Scripts -->
    <style>
        .btn-info{
            color: #fff;
        }
    </style>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
       
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">




                
                <a class="navbar-brand" style="margin-left:40px; margin-top:10px;" href="<?php echo e(url('/cmsadmin/index')); ?>">
                    Dobrodošli, ADMINISTRATOR!
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                    </ul>
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                     <a class="dropdown-item" href="#">
                                        Moj profil
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Odjava')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4">
        <?php if(auth()->guard()->check()): ?>
        <div class="container"> 
         
            
        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row" style="justify-content: center; ">
            <div class="col-md-8" style="margin-bottom:30px;">
                <ul class="list-group list-group-horizontal" style="display:flex";  >
                    <?php if(auth()->user()->isAdmin()): ?>
                   
                    <?php endif; ?>
                    <li class="list-group-item" style="width: 100%; text-align:center; padding-top:20px;">
                        <a href="<?php echo e(route('brod.index')); ?>">Brodovi</a>
                    </li>
                    <li class="list-group-item" style="width: 100%; text-align:center; padding-top:20px;">
                        <a href="<?php echo e(route('ruta.index')); ?>">Rute</a>
                    </li>
                    <li class="list-group-item" style="width: 100%; text-align:center; padding-top:20px;">
                        <a href="<?php echo e(route('zaposlenik.index')); ?>">Zaposlenici</a>
                    </li>
                    <li class="list-group-item" style="width: 100%; text-align:center; ">
                        <a href="<?php echo e(route('kategorija.index')); ?>">Kategorije gostiju</a>
                    </li>
                    <li class="list-group-item" style="width: 100%; text-align:center; padding-top:20px;">
                        <a href="#">Gosti</a>
                    </li>
                    <li class="list-group-item" style="width: 100%; text-align:center; padding-top:20px;">
                        <a href="#">Putovanja</a>
                    </li>
                  
                </ul>
               
            </div> 
            
            <?php echo $__env->yieldContent('succeslogin'); ?>
            <div>
            <?php echo $__env->yieldContent('content'); ?>
            </div>
            </div>
            
        </div>
        <?php endif; ?>
        </main>
    </div>
    
    <script src="<?php echo e(asset('js/app.js')); ?>" ></script> 
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\iooaizleti\resources\views/cms/master.blade.php ENDPATH**/ ?>